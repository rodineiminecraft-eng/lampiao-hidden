#!/bin/sh
set -e
gradle build
echo ""
echo "JAR GERADO:"
ls -lh build/libs/*.jar
