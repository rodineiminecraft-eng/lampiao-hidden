package com.jczzwt.lampiaohidden;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomDataComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityEquipmentUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class LampiaoHidden implements ModInitializer {
    private static final String MOD_ID = "lampiao_hidden";
    private static final String LAMPIAO_KEY = "lampiao_lendario";

    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                boolean active = isLampiao(player);

                if (active) {
                    hideFromOthers(player);
                } else {
                    showToOthers(player);
                }
            }
        });
    }

    private static boolean isLampiao(PlayerEntity player) {
        return hasLampiao(player.getMainHandStack()) || hasLampiao(player.getOffHandStack());
    }

    private static boolean hasLampiao(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(net.minecraft.item.Items.SOUL_LANTERN)) return false;

        CustomDataComponent data = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (data == null) return false;

        return data.copyNbt().getBoolean(LAMPIAO_KEY).orElse(false);
    }

    private static void hideFromOthers(ServerPlayerEntity player) {
        List<EquipmentSlot> slots = List.of(
                EquipmentSlot.MAINHAND,
                EquipmentSlot.OFFHAND,
                EquipmentSlot.HEAD,
                EquipmentSlot.CHEST,
                EquipmentSlot.LEGS,
                EquipmentSlot.FEET
        );

        List<com.mojang.datafixers.util.Pair<EquipmentSlot, ItemStack>> equipment = new ArrayList<>();
        for (EquipmentSlot slot : slots) {
            equipment.add(com.mojang.datafixers.util.Pair.of(slot, ItemStack.EMPTY));
        }

        EntityEquipmentUpdateS2CPacket packet =
                new EntityEquipmentUpdateS2CPacket(player.getId(), equipment);

        for (ServerPlayerEntity viewer : player.getServer().getPlayerManager().getPlayerList()) {
            if (viewer != player) {
                viewer.networkHandler.sendPacket(packet);
            }
        }
    }

    private static void showToOthers(ServerPlayerEntity player) {
        List<EquipmentSlot> slots = List.of(
                EquipmentSlot.MAINHAND,
                EquipmentSlot.OFFHAND,
                EquipmentSlot.HEAD,
                EquipmentSlot.CHEST,
                EquipmentSlot.LEGS,
                EquipmentSlot.FEET
        );

        List<com.mojang.datafixers.util.Pair<EquipmentSlot, ItemStack>> equipment = new ArrayList<>();
        for (EquipmentSlot slot : slots) {
            equipment.add(com.mojang.datafixers.util.Pair.of(slot, player.getEquippedStack(slot)));
        }

        EntityEquipmentUpdateS2CPacket packet =
                new EntityEquipmentUpdateS2CPacket(player.getId(), equipment);

        for (ServerPlayerEntity viewer : player.getServer().getPlayerManager().getPlayerList()) {
            if (viewer != player) {
                viewer.networkHandler.sendPacket(packet);
            }
        }
    }
}
