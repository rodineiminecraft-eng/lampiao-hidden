LAMPIAO HIDDEN - Minecraft 1.21.11 / Fabric

Funcao:
- Server-side.
- Detecta um soul_lantern com custom_data lampiao_lendario:1b.
- Enquanto estiver na mao principal ou secundaria, os outros jogadores recebem os slots de mao/armadura vazios.
- O proprio jogador continua vendo seus itens normalmente.
- Ao soltar/trocar o Lampiao, os equipamentos reais voltam a ser enviados.

Compilar:
1. Tenha Java 21 instalado.
2. No Windows: gradlew.bat build
3. No Linux/macOS: ./gradlew build

O JAR sai em:
build/libs/lampiao-hidden-1.0.0.jar

Instalacao:
- Coloque o JAR na pasta mods do servidor Fabric 1.21.11.
- Reinicie o servidor.

IMPORTANTE:
Este projeto foi preparado para o Fabric 1.21.11 e usa Fabric API 0.141.6+1.21.11.
