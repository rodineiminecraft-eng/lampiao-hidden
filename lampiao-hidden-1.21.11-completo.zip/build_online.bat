@echo off
gradle build
echo.
echo JAR GERADO:
dir build\libs\*.jar
